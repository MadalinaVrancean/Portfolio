# Progress tracking — Power BI demo

Recreated from the supplied screenshot using native Power BI visuals and entirely fictional data. No connection to SHV systems.

## Open
1. Extract the ZIP to a local folder on Windows. Keep both project folders next to `Progress.pbip`.
2. Use a current Power BI Desktop release with Power BI Project, TMDL semantic model, and enhanced report format (PBIR) support. Enable the relevant preview options under File → Options → Preview features if your release requires them, then restart Desktop.
3. Open `Progress.pbip`, then select Home → Refresh to load the embedded dummy tables.
4. View the Progress tracking page. Select the Validation tracker page for the 35 reporting-unit records and status/country dropdown filters.
5. Save locally; optionally use Save As to produce a `.pbix`, then publish using your own authorized Power BI account.

No database, credentials, gateway, or CSV path configuration is needed. Data is embedded in the semantic model's Power Query M partitions. CSV copies in `data/` are supplied for inspection; editing those CSV files alone does not refresh the embedded model. To change dummy records, edit the Power Query source table in Desktop or the corresponding TMDL partition with Desktop closed.

## Included
- Editable `.pbip`, PBIR report definition, and TMDL semantic model.
- Four workflow panels, KPI cards, validation distribution, and a reporting-unit detail page.
- 35 reporting units: 25 signed off, 7 with comments, 3 pending. Validation is 25/35 = 71.43%, displayed as 71%.
- Three loaded files and three processed layers, each showing 100%.
- `preview.html`: browser-openable static design reference, not a Power BI render.
- `theme.json`: optional importable palette.

## Scope and validation
The selected period is a fixed July 2026 demo. Top period/pillar/theme labels and workflow indicators are presentation text, not selectors. Navigation-like header tabs, deadline text, and the tracker caption are not application buttons. Use the native report page tabs for navigation. No upload, Fabric processing, approval, deadline editing, or head-office sending occurs. These actions require an application or Power Automate integration and real backend services.

Model measures are driven by dummy tables. The overview is intended for the full July cohort; the separate detail-page slicers filter detail records only. `Send status` remains `Not sent` for this cohort. It can indicate readiness for approval but does not perform an approval or transmission.

JSON definitions were checked against Microsoft's public schemas, with embedded counts and references checked locally. Power BI Desktop rendering, model compilation, and publishing cannot be executed in this Linux environment and require a final Windows Desktop check. Font metrics and spacing may vary by Desktop version; this is a close recreation, not a verified pixel-perfect export.
