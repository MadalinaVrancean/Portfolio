@echo off
setlocal
cd /d "%~dp0"
if not exist "Progress.pbip" goto incomplete
if not exist "Progress.Report\definition.pbir" goto incomplete
if not exist "Progress.SemanticModel\definition.pbism" goto incomplete
if not exist "Progress.SemanticModel\definition\model.tmdl" goto incomplete
if not exist "Progress.SemanticModel\definition\tables\Units.tmdl" goto incomplete
start "" "%~dp0Progress.pbip"
exit /b 0
:incomplete
echo The complete Power BI project is not available in this folder.
echo Close this window, right-click the ZIP and choose Extract All.
echo Then run Open-Report.cmd from the extracted folder.
pause
exit /b 1
